self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "724fdc8f33520fe39fa8b982729dc151",
    "url": "/index.html"
  },
  {
    "revision": "8f055b136a8296688960",
    "url": "/static/js/2.48808265.chunk.js"
  },
  {
    "revision": "d5b445a81227876e9f4080bf0648eb92",
    "url": "/static/js/2.48808265.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b8f01a0cd37cc7dc3ef6",
    "url": "/static/js/main.13f69928.chunk.js"
  },
  {
    "revision": "19af52671b05553f8765",
    "url": "/static/js/runtime-main.47b912c7.js"
  }
]);